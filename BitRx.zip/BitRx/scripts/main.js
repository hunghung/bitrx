// Code goes here
(function() {

  bitrxdb = null;
  subpages = null;

  $.getJSON("./bitrxdb.json", function(data) {
    bitrxdb = data;
    initDBAPI();
    initDataCompleted();
  })

  function initDBAPI(){
    
  }

  function initDataCompleted() {
    $(document).ready(function() {
      $("#header").load("./header.html");
      $("#footer").load("./footer.html");
    });
  }

}())